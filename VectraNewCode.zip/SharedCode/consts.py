"""Constants used in the code."""

import os

SENTINEL_RETRY_COUNT = 3
API_TIMEOUT = 180
API_RETRY_COUNT = 3
WORKSPACE_ID = os.environ.get("WORKSPACE_ID")
WORKSPACE_KEY = os.environ.get("WORKSPACE_KEY")
LOG_LEVEL = os.environ.get("LOG_LEVEL")
ENTITY_SCORING_CLIENT_ID = os.environ.get("ENTITY_SCORING_CLIENT_ID")
ENTITY_SCORING_CLIENT_SECRET = os.environ.get("ENTITY_SCORING_CLIENT_SECRET")
CONNECTION_STRING = os.environ.get("AzureWebJobsStorage")
ENTITY_SCORING_NAME = "Entity Scoring"
ENTITY_SCORING_ACCOUNT_NAME = " Entity Scoring : Account"
ENTITY_SCORING_HOST_NAME = " Entity Scoring : Host"
START_TIME = os.environ.get("StartTime", "")
INCLUDE_SCORE_DECREASE = os.environ.get("IncludeScoreDecrease").lower()
USER_AGENT = "Vectra-Sentinel-2.0.0"
ENTITY_SCORING_TABLE_NAME = os.environ.get("ENTITY_SCORING_TABLE_NAME", "Vectra_Entity_Scoring_Data")
TENANT_ID = os.environ.get("TENANT_ID")
AZURE_CLIENT_ID = os.environ.get("AZURE_CLIENT_ID")
AZURE_CLIENT_SECRET = os.environ.get("AZURE_CLIENT_SECRET")
AZURE_SUBSCRIPTION_ID = os.environ.get("AZURE_SUBSCRIPTION_ID")
AZURE_RESOURCE_GROUP = os.environ.get("AZURE_RESOURCE_GROUP")
KEYVAULT_NAME = os.environ.get("KEYVAULT_NAME")
BASE_URL = os.environ.get("BASE_URL")
OAUTH2_ENDPOINT = "/oauth2/token"
ENTITY_SCORING_ENDPOINT = "/api/v3.3/events/entity_scoring"
