import time
from requests.adapters import HTTPAdapter
from urllib3.util import Retry
from SharedCode.vectra_exception import VectraException
from SharedCode.vectra_logger import applogger
from SharedCode import consts
import base64
import datetime
import hashlib
import hmac
import requests
from urllib3.exceptions import NameResolutionError


customer_id = consts.WORKSPACE_ID
shared_key = consts.WORKSPACE_KEY
_RETRY_STATUS_CODES = {
    429: "Error occurred: Too many request. sleeping for {} seconds and retrying..".format(
        consts.SENTINEL_INGESTION_ERROR_SLEEP_TIME
    ),
    500: "Error occurred: Internal Server Error. sleeping for {} seconds and retrying..".format(
        consts.SENTINEL_INGESTION_ERROR_SLEEP_TIME
    ),
    503: "Error occurred: Service Unavailable. sleeping for {} seconds and retrying..".format(
        consts.SENTINEL_INGESTION_ERROR_SLEEP_TIME
    ),
}


class MicrosoftSentinel:
    """MicrosoftSentinel class is used to post data into log Analytics workspace."""

    def __init__(self):
        """Initialize the MicrosoftSentinel client with retry configuration."""
        # Set up the session with retry logic
        self.session = requests.Session()

        # Configure retry strategy
        retry_strategy = Retry(
            total=consts.SENTINEL_RETRY_COUNT,
            backoff_factor=2,
            status_forcelist=list(_RETRY_STATUS_CODES.keys()),  # [429, 500, 503]
            allowed_methods=["POST"],
            raise_on_status=False,
        )

        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("https://", adapter)

    def build_signature(
        self,
        date,
        content_length,
        method,
        content_type,
        resource,
    ):
        """To build signature which is required in header."""
        x_headers = "x-ms-date:" + date
        string_to_hash = method + "\n" + str(content_length) + "\n" + content_type + "\n" + x_headers + "\n" + resource
        bytes_to_hash = bytes(string_to_hash, encoding="utf-8")
        decoded_key = base64.b64decode(shared_key)
        encoded_hash = base64.b64encode(
            hmac.new(decoded_key, bytes_to_hash, digestmod=hashlib.sha256).digest()
        ).decode()
        authorization = "SharedKey {}:{}".format(customer_id, encoded_hash)
        return authorization

    def post_data(self, body, log_type):
        """Build and send a request to the POST API with automatic retries."""
        method = "POST"
        content_type = "application/json"
        resource = "/api/logs"
        rfc1123date = datetime.datetime.now(datetime.timezone.utc).strftime("%a, %d %b %Y %H:%M:%S GMT")
        content_length = len(body)

        try:
            signature = self.build_signature(
                rfc1123date,
                content_length,
                method,
                content_type,
                resource,
            )
            # ! update it using environment.url something said by Jayesh
            uri = f"https://{consts.WORKSPACE_ID}.ods.opinsights.azure.com{resource}?api-version=2016-04-01"

            headers = {
                "content-type": content_type,
                "Authorization": signature,
                "Log-Type": log_type,
                "x-ms-date": rfc1123date,
            }

            start_time = time.time()
            # Use the session with configured retry
            response = self.session.post(uri, data=body, headers=headers, timeout=consts.SENTINEL_MAX_TIMEOUT)
            duration = time.time() - start_time
            applogger.debug(f"Response Time for sending data to Microsoft Sentinel: {duration:.3f} sec")

            # Handle response
            if 200 <= response.status_code < 300:
                applogger.info(f"{response.status_code} Accepted: Data Posted Successfully to Microsoft Sentinel.")
                return response.status_code
            else:
                applogger.error(f"Error posting data to Microsoft Sentinel: {response.status_code} {response.text}")
                if response.status_code == 400:
                    applogger.error(
                        "Error occurred: Response code: "
                        "{} Bad Request while posting data to log analytics.\nError: {}".format(
                            response.status_code, response.content
                        )
                    )
                    raise VectraException("Invalid data format for Microsoft Sentinel.")
                elif response.status_code == 403:
                    applogger.error(
                        "Error occurred for build signature: Issue with WorkspaceKey. Kindly verify your WorkspaceKey."
                    )
                    raise VectraException(
                        "Error occurred for build signature: Issue with WorkspaceKey. Kindly verify your WorkspaceKey."
                    )
                else:
                    raise VectraException(
                        f"Failed to post data to Microsoft Sentinel. Status code: {response.status_code}"
                    )

        except (requests.exceptions.ConnectionError, NameResolutionError) as e:
            applogger.error(f"Connection error with Microsoft Sentinel: {e}")
            raise VectraException(f"Failed to connect to Microsoft Sentinel: {e}")
        except Exception as e:
            applogger.error(f"Unexpected error posting to Microsoft Sentinel: {e}")
            raise VectraException(f"Unexpected error: {e}")
