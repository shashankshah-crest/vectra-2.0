"""This collector file will pull and push the data."""

import datetime
import json
import requests
from requests.auth import HTTPBasicAuth
from SharedCode.sentinel import MicrosoftSentinel
from SharedCode import consts
from SharedCode.keyvault_management import KeyVaultSecretManage
from SharedCode.vectra_exception import VectraException, VectraIncorrectCredentialsException


class BaseCollector:
    def __init__(self, applogger, function_name, client_id, client_secret) -> None:
        self.applogger = applogger
        self.function_name = function_name
        self.client_id = client_id
        self.client_secret = client_secret
        self.connection_string = consts.CONNECTION_STRING
        self.base_url = consts.BASE_URL
        self.access_token = None
        self.refresh_token = None
        self.access_token_expires_in_time = None
        self.refresh_token_expires_in_time = None
        self.sentinel_obj = MicrosoftSentinel()
        self.keyvault_obj = KeyVaultSecretManage(self.applogger)
        self.session = requests.Session()
        self.session.headers["User-Agent"] = consts.USER_AGENT
        self.session.headers["Content-Type"] = "application/x-www-form-urlencoded"
        self.start_time = consts.START_TIME

    def validate_params(self, client_id_key: str, client_secret_key: str) -> None:
        """Validate the parameters."""
        try:
            required_params = {
                client_id_key: self.client_id,
                client_secret_key: self.client_secret,
                "BaseUrl": consts.BASE_URL,
                "Workspace_ID": consts.WORKSPACE_ID,
                "Workspace_Key": consts.WORKSPACE_KEY,
                "Tenant_ID": consts.TENANT_ID,
                "Azure_Client_ID": consts.AZURE_CLIENT_ID,
                "Azure_Client_Secret": consts.AZURE_CLIENT_SECRET,
                "Azure_Subscription_ID": consts.AZURE_SUBSCRIPTION_ID,
                "Azure_Resource_Group": consts.AZURE_RESOURCE_GROUP,
                "Entity_Scoring_Table_Name": consts.ENTITY_SCORING_TABLE_NAME,
                "KeyVaultName": consts.KEYVAULT_NAME,
            }
            missing_param = False
            for param, value in required_params.items():
                if not value:
                    missing_param = True
                    self.applogger.warning(
                        "{} parameter is missing. Found value: {}".format(param, value)
                    )
            if missing_param:
                raise ValueError("Missing required parameters")
            if not self.base_url.startswith("https://"):
                self.applogger.error(
                    "BaseUrl should start with https://, Found value: {}".format(
                        self.base_url
                    )
                )
                raise ValueError("BaseUrl should start with https://")
            self.applogger.info("Parameter validation successful.")
        except ValueError as value_err:
            self.applogger.error(
                "Parameter validation failed. Error: {}".format(value_err)
            )
            raise VectraException(value_err)
        except Exception as unknown_err:
            self.applogger.error(
                "Parameter validation failed. Unknown Error: {}".format(unknown_err)
            )
            raise VectraException(unknown_err)

    def validate_connection(self) -> None:
        """Validate the connection to Vectra."""
        try:
            self.load_secrets()
            self.load_expiry_time_from_checkpoint()
            self.validate_tokens()
        except VectraException:
            raise VectraException()

    def load_secrets(self) -> None:
        """Load the secrets from KeyVault."""
        try:
            self.access_token = self.keyvault_obj.get_keyvault_secret(
                self.access_token_key
            )
            self.refresh_token = self.keyvault_obj.get_keyvault_secret(
                self.refresh_token_key
            )
        except Exception as unknown_err:
            self.applogger.error(
                "Unknown Error while loading secrets. Error: {}".format(unknown_err)
            )
            raise VectraException(unknown_err)

    def validate_tokens(self) -> None:
        """Validate the tokens.

        Raises:
            VectraException: If any error occurs.
        """
        try:
            if self.access_token:
                if self.is_token_expired(self.access_token_expires_in_time) and not self.is_token_expired(
                    self.refresh_token_expires_in_time
                ):
                    self.applogger.info(
                        "Access token expired. Generating new access token using refresh token."
                    )
                    self.generate_access_token(from_refresh_token=True)
                elif self.is_token_expired(self.access_token_expires_in_time) and self.is_token_expired(
                    self.refresh_token_expires_in_time
                ):
                    self.applogger.info(
                        "Both access token and refresh token are expired or expiration time does not exist."
                    )
                    self.generate_access_token()
                else:
                    self.applogger.info(
                        "Using existing and valid access token."
                    )
            else:
                self.applogger.info(
                    "Access token does not exist.Generating new access token and refresh token."
                )
                self.generate_access_token()
        except VectraException as err:
            raise VectraException(err)
        except VectraIncorrectCredentialsException as err:
            raise VectraException(err)

    def load_expiry_time_from_checkpoint(self) -> None:
        """Load the expiry time from checkpoint.

        Raises:
            VectraException: If any error occurs.
        """
        try:
            data = self.state.get()
            if data and data is not None:
                data = json.loads(data)
                self.access_token_expires_in_time = data.get(self.access_token_expires_in, None)
                self.refresh_token_expires_in_time = data.get(
                    self.refresh_token_expires_in, None
                )
            else:
                self.applogger.info(
                    "No data found in checkpoint. This might be the first run or the checkpoint file got deleted."
                )
        except json.JSONDecodeError as json_err:
            self.applogger.error(
                "Error while loading expiry time from checkpoint. JSON Decode Error: {}".format(
                    json_err
                )
            )
            raise VectraException(json_err)
        except Exception as unknown_err:
            self.applogger.error(
                "Unknown Error while loading expiry time from checkpoint. Error: {}".format(
                    unknown_err
                )
            )
            raise VectraException(unknown_err)

    def is_token_expired(self, token_expiration_time) -> bool:
        """Check if the token is expired."""
        if not token_expiration_time:
            return True
        current_time = datetime.datetime.now().isoformat()
        return True if current_time > token_expiration_time else False

    def generate_access_token(self, from_refresh_token=False) -> None:
        """Generate access token.

        Args:
            from_refresh_token (bool, optional): If True, generate access token from refresh token. Defaults to False.

        Raises:
            VectraIncorrectCredentialsException: If the credentials are incorrect.
            VectraException: If any error occurs.
        """
        access_token_url = self.base_url + consts.OAUTH2_ENDPOINT
        data = {"grant_type": "client_credentials" if not from_refresh_token else "refresh_token"}
        auth = HTTPBasicAuth(self.client_id, self.client_secret)
        if from_refresh_token:
            data["refresh_token"] = self.refresh_token
        try:
            response = self.session.post(
                access_token_url, data=data, timeout=consts.API_TIMEOUT, auth=auth
            )
            if response.status_code in [200, 201]:
                response = response.json()
                self.access_token = response.get("access_token")
                self.refresh_token = response.get("refresh_token")
                self.session.headers["Authorization"] = "Bearer {}".format(
                    self.access_token
                )
                # shall we use .get() or [""] -> which will be better? -> Identify
                self.add_expiration_time_to_checkpoint(
                    response.get("expires_in"),
                    response.get("refresh_expires_in"),
                    from_refresh_token,
                )
            elif response.status_code == 401:
                self.applogger.error(
                    "Access Token Generation Failed. Status Code: {}, Check your client_id and client_secret.".format(
                        response.status_code
                    )
                )
                raise VectraIncorrectCredentialsException("Invalid Client ID or Client Secret.")
            elif response.status_code in [400, 403, 404]:
                self.applogger.error(
                    "Access Token Generation Failed. Status Code: {}, Response: {}.".format(
                        response.status_code, response.json()
                    )
                )
                raise VectraException()
            else:
                self.applogger.error(
                    "Access Token Generation Failed. Status Code: {}, Response: {}".format(
                        response.status_code, response.json()
                    )
                )
                raise VectraException()
        except VectraIncorrectCredentialsException:
            raise VectraIncorrectCredentialsException()
        except VectraException:
            raise VectraException()
        except Exception as unknown_err:
            self.applogger.error(
                "Unknown Error while generating access token. Error: {}".format(
                    unknown_err
                )
            )
            raise VectraException()

    def make_rest_call(
        self, url, params=None, timeout=consts.API_TIMEOUT, method="GET"
    ):
        """Make a REST call."""
        try:
            self.applogger.info(
                "Making API call. Method: {}, URL: {}, Version: {}".format(method, url, self.session.headers["User-Agent"])
            )
            for _ in range(0, consts.RETRY_COUNT):
                if method.lower() == "post":
                    res = self.session.post(url, params=params, timeout=timeout)
                else:
                    res = self.session.get(url, params=params, timeout=timeout)
                if res.status_code in [200, 201]:
                    self.applogger.info(
                        "API call successful. Status Code: {}".format(res.status_code)
                    )
                    return res.json()
                elif res.status_code == 401:
                    self.applogger.error(
                        "Access Token Expired. Status Code: {}, Generating New Access Token.".format(
                            res.status_code
                        )
                    )
                    self.validate_tokens()
                    continue
                elif res.status_code in [400, 403, 404]:
                    self.applogger.error(
                        "API call failed. Status Code: {}, Response: {}.".format(
                            res.status_code, res.json()
                        )
                    )
                    raise VectraException()
                else:
                    self.applogger.error(
                        "API call failed. Status Code: {}, Response: {}".format(
                            res.status_code, res.json()
                        )
                    )
                    raise VectraException()
        except requests.exceptions.RequestException as request_err:
            self.applogger.error(
                "Request Exception while making REST call. Error: {}".format(
                    request_err
                )
            )
            raise VectraException()
        except VectraException:
            raise VectraException()
        except Exception as unknown_err:
            self.applogger.error(
                "Unknown Error while making REST call. Error: {}".format(unknown_err)
            )
            raise VectraException()

    def pull_and_push_the_data(
        self, endpoint, field, checkpoint, table_name, query_params={}
    ):
        """Pull and push the data.

        Args:
            endpoint (str): endpoint on which the data will be pulled
            field (str): field which will be used for pulling the data
            checkpoint (dict): checkpoint data which will be used to pull the data
            table_name (str): table name in which the data will be pushed
            query_params (dict, optional): query parameters which will be passed with the API call. Defaults to {}.

        Raises:
            VectraException: If any error occurs while pulling or pushing the data
        """
        url = self.base_url + endpoint
        try:
            if endpoint == consts.ENTITY_SCORING_ENDPOINT:
                self.applogger.info(
                    "Pulling and Pushing Entity Scoring data. Endpoint: {}".format(
                        endpoint
                    )
                )
                self.pull_and_push_entity_scoring_data(
                    url, field, checkpoint, table_name, query_params
                )
        except Exception as unknown_err:
            self.applogger.error(
                "Unknown Error while pulling and pushing data. Error: {}".format(
                    unknown_err
                )
            )
            raise VectraException(unknown_err)

    def pull_and_push_entity_scoring_data(
        self, url, field, checkpoint, table_name, query_params
    ):
        """Fetch entity scoring data and ingest it into Sentinel.

        Args:
            url (str): url of the API endpoint
            field (str): name of the checkpoint field
            checkpoint (str): value of the checkpoint field
            table_name (str): name of the Sentinel table
            query_params (dict): additional query parameters to pass in the API call
        """
        query_params.update({"limit": consts.PAGE_SIZE, field: checkpoint})
        iter_next = True
        while iter_next:
            response = self.make_rest_call(
                url, params=query_params
            )
            events = response.get("events")
            if events and len(events):
                self.create_chunks_and_ingest_into_sentinel(
                    events, table_name
                )
                # ! shall we need to provide default value for next_page_start -> Think
                next_page_start = response.get("next_checkpoint")
                query_params.update({"from": next_page_start})
                self.save_checkpoint(
                    data={"from": next_page_start}
                )
                iter_next = True if int(response.get("remaining_count")) > 0 else False

    def get_checkpoint_field_and_value(self):
        """Get the checkpoint field and value."""
        # ! remove self.start_time initialization from here if it is only used for entity scoring endpoint.
        field = None
        try:
            checkpoint_value = self.state.get()
            if checkpoint_value:
                checkpoint_data = json.loads(checkpoint_value)
                if checkpoint_data.get("from", None):
                    field, checkpoint_data = "from", checkpoint_data.get("from")
                elif checkpoint_data.get("event_timestamp_gte", None):
                    field, checkpoint_data = "event_timestamp_gte", checkpoint_data.get("event_timestamp_gte")
                else:
                    field, checkpoint_data = "event_timestamp_gte", self.start_time
                    self.state.post(json.dumps({"event_timestamp_gte": self.start_time}))
            else:
                field, checkpoint_data = "event_timestamp_gte", self.start_time
                self.state.post(json.dumps({"event_timestamp_gte": self.start_time}))
            self.applogger.info(
                'Checkpoint field="{}" and value="{}"'.format(
                    field,
                    checkpoint_data,
                )
            )
            return field, checkpoint_data
        except Exception as err:
            self.applogger.error(
                'Unexpected error while getting checkpoint: err="{}"'.format(
                    err
                )
            )
            raise VectraException(err)

    def create_chunks_and_ingest_into_sentinel(self, data, table_name):
        """Split data into chunks and ingest into Sentinel.

        Args:
            data (list): List of data records to be ingested
            table_name (str): Name of the Sentinel table to ingest data into

        Raises:
            VectraException: If any error occurs during ingestion
        """
        try:
            # ! chunk partition remains.
            self.sentinel_obj.post_data(json.dumps(data), table_name)
        except VectraException as unknown_err:
            self.applogger.error(
                "Unknown Error while creating chunks and ingesting into sentinel. Error: {}".format(
                    unknown_err
                )
            )
            raise VectraException(unknown_err)

    def add_expiration_time_to_checkpoint(
        self,
        access_token_expires_in,
        refresh_token_expires_in,
        from_refresh_token: bool,
    ):
        """Add secrets to checkpoint."""
        try:
            self.access_token_expires_in_time = (
                datetime.datetime.now()
                + datetime.timedelta(seconds=access_token_expires_in)
            ).isoformat()
            data = {self.access_token_expires_in: self.access_token_expires_in_time}
            if from_refresh_token:
                self.refresh_token_expires_in_time = (
                    datetime.datetime.now()
                    + datetime.timedelta(seconds=refresh_token_expires_in)
                ).isoformat()
                data.update({self.refresh_token_expires_in: self.refresh_token_expires_in_time})
            self.save_checkpoint(data, token_expiration=True)
        except Exception as unknown_err:
            self.applogger.error(
                "Unknown Error while adding secrets to checkpoint. Error: {}".format(
                    unknown_err
                )
            )
            raise unknown_err

    def save_checkpoint(self, data, token_expiration=False):
        """Save the checkpoint."""
        try:
            checkpoint_data = self.state.get()
            checkpoint_data_json = {}
            if checkpoint_data and checkpoint_data is not None:
                checkpoint_data_json = json.loads(checkpoint_data)
            # if token_expiration:
                # checkpoint_data.update(data)
            checkpoint_data_json.update(data)
            self.state.post(json.dumps(checkpoint_data_json))
        except Exception as unknown_err:
            self.applogger.error(
                "Unknown Error while saving checkpoint. Error: {}".format(unknown_err)
            )
            raise VectraException(unknown_err)
