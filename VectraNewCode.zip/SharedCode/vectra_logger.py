import logging
import sys
from ..SharedCode import consts


class CustomFormatter(logging.Formatter):
    """Class to format the log messages"""

    def format(self, record: logging.LogRecord) -> str:
        """
        Format the log message.

        This method formats the log message by adding the calling
        function name and the log message itself.

        Args:
            record (logging.LogRecord): The log record to be formatted.

        Returns:
            str: The formatted log message.
        """

        func_name = record.funcName
        message = record.getMessage()

        log_format = f"Vectra: (method={func_name}) : {message}"
        record.msg = log_format
        record.args = ()

        return log_format


level_str = consts.LOG_LEVEL.upper()
level = getattr(logging, level_str, logging.INFO)

app_logger = logging.getLogger("azure")
app_logger.setLevel(level)

console_handler = logging.StreamHandler(sys.stdout)
console_handler.setFormatter(CustomFormatter())
app_logger.addHandler(console_handler)
