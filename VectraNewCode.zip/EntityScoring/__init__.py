"""This __init__ file will be called once triggered is generated."""

import sys
import time
import traceback
import azure.functions as func
from ..SharedCode import consts
from ..SharedCode.vectra_logger import applogger
from .entity_scoring_collector import EntityScoringCollector
from ..SharedCode.vectra_exception import VectraException


def main(mytimer: func.TimerRequest) -> None:
    """Start the execution.

    Args:
        mytimer (func.TimerRequest): timer trigger
    """
    try:
        applogger.info(" : {} : execution started.".format(consts.ENTITY_SCORING_NAME))
        start_time = time.time()
        entity_scoring_obj = EntityScoringCollector(
            applogger,
            consts.ENTITY_SCORING_NAME,
            consts.ENTITY_SCORING_CLIENT_ID,
            consts.ENTITY_SCORING_CLIENT_SECRET,
        )
        entity_scoring_obj.validate_params(
            "ENTITY_SCORING_CLIENT_ID",
            "ENTITY_SCORING_CLIENT_SECRET",
        )
        applogger.info(
            " : {} : Parameter validation successful.".format(
                consts.ENTITY_SCORING_NAME,
            )
        )
        entity_scoring_obj.validate_connection()
        applogger.info(
            " : {} : Established connection with Vectra successfully.".format(
                consts.ENTITY_SCORING_NAME,
            )
        )
        entity_scoring_obj.function_name = consts.ENTITY_SCORING_ACCOUNT_NAME
        entity_scoring_obj.get_entity_scoring_data_and_ingest_into_sentinel("account")
        # entity_scoring_obj.get_entity_scoring_data_and_ingest_into_sentinel_account()
        entity_scoring_obj.function_name = consts.ENTITY_SCORING_HOST_NAME
        entity_scoring_obj.get_entity_scoring_data_and_ingest_into_sentinel("host")
        # entity_scoring_obj.get_entity_scoring_data_and_ingest_into_sentinel_host()
        entity_scoring_obj.function_name = consts.ENTITY_SCORING_NAME
        applogger.info(
            " : {} : time taken for data ingestion is {} sec.".format(
                consts.ENTITY_SCORING_NAME,
                int(time.time() - start_time),
            )
        )
        applogger.info(
            " : {} : execution completed.".format(consts.ENTITY_SCORING_NAME)
        )
        if mytimer.past_due:
            applogger.info(
                " : {} : The timer is past due!".format(
                    consts.ENTITY_SCORING_NAME,
                )
            )
    except VectraException:
        sys.exit(1)
    except Exception as ex:
        applogger.error(
            ' : {} : Unexpected error while getting data: error="{}" error_trace="{}"'.format(
                consts.ENTITY_SCORING_NAME,
                str(ex),
                traceback.format_exc(),
            )
        )
        sys.exit(1)
