"""Logging configuration for Vectra XDR Data Connector."""
import logging
import sys
import os


def get_log_level() -> int:
    """
    Get log level from environment variable with validation.
    
    Reads the 'LogLevel' environment variable and returns the corresponding
    logging level. If the value is invalid or not set, returns INFO as default.
    
    Valid values (case-insensitive): debug, info, warning, error
    
    Returns:
        Logging level constant (e.g., logging.INFO)
    """
    log_level_str = os.environ.get("LogLevel", "INFO").upper()
    
    # Map of valid log level strings to logging constants
    valid_log_levels = {
        "DEBUG": logging.DEBUG,
        "INFO": logging.INFO,
        "WARNING": logging.WARNING,
        "ERROR": logging.ERROR,
    }
    
    # Return the log level if valid, otherwise default to INFO
    return valid_log_levels.get(log_level_str, logging.INFO)


# Get the configured log level
configured_log_level = get_log_level()

# Configure the Azure logger
applogger = logging.getLogger("azure")
applogger.setLevel(configured_log_level)

# Create console handler if not already present
if not applogger.handlers:
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(configured_log_level)
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    )
    handler.setFormatter(formatter)
    applogger.addHandler(handler)


# Sensitive fields to sanitize in logs
SENSITIVE_FIELDS = [
    "password",
    "token",
    "api_key",
    "secret",
    "authorization",
    "client_secret",
    "workspace_key",
]


def sanitize_log_message(message: str) -> str:
    """
    Sanitize sensitive information from log messages.

    Args:
        message: The log message to sanitize.

    Returns:
        Sanitized log message with sensitive data masked.
    """
    sanitized = message
    for field in SENSITIVE_FIELDS:
        if field.lower() in sanitized.lower():
            # Simple masking - in production, use regex for better accuracy
            sanitized = sanitized.replace(field, "[REDACTED]")
    return sanitized
