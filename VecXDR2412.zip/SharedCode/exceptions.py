"""Custom exceptions for Vectra XDR Data Connector."""


class DataConnectorException(Exception):
    """Base exception for data connector errors."""

    pass


class APIAuthenticationException(DataConnectorException):
    """Exception raised when API authentication fails."""

    pass


class APIRateLimitException(DataConnectorException):
    """Exception raised when API rate limit is exceeded."""

    pass


class DataIngestionException(DataConnectorException):
    """Exception raised when data ingestion to Sentinel fails."""

    pass


class InvalidResponseException(DataConnectorException):
    """Exception raised when API returns an invalid response."""

    pass


class CheckpointException(DataConnectorException):
    """Exception raised when checkpoint operations fail."""

    pass


class ConfigurationException(DataConnectorException):
    """Exception raised when configuration is invalid or missing."""

    pass
