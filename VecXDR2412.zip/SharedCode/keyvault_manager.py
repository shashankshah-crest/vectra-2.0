"""Key Vault manager for secure token storage."""
import inspect
from typing import Optional
from azure.keyvault.secrets import SecretClient
from azure.identity import ClientSecretCredential, AzureAuthorityHosts
from azure.core.exceptions import ResourceNotFoundError
from SharedCode.logger import applogger
from SharedCode.consts import (
    LOGS_STARTS_WITH,
    KEY_VAULT_NAME,
    AZURE_CLIENT_ID,
    AZURE_CLIENT_SECRET,
    AZURE_TENANT_ID,
    SCOPE,
    KV_ACCESS_TOKEN_SECRET,
    KV_REFRESH_TOKEN_SECRET,
)
from SharedCode.exceptions import ConfigurationException


class KeyVaultManager:
    """Manage OAuth tokens in Azure Key Vault."""

    def __init__(self):
        """
        Initialize the KeyVaultManager.

        Raises:
            ConfigurationException: If Key Vault configuration is missing.
        """
        self.logs_starts_with = f"{LOGS_STARTS_WITH} KeyVaultManager:"
        __method_name = inspect.currentframe().f_code.co_name

        if not KEY_VAULT_NAME:
            raise ConfigurationException("KEY_VAULT_NAME is not configured.")

        if not all([AZURE_CLIENT_ID, AZURE_CLIENT_SECRET, AZURE_TENANT_ID]):
            raise ConfigurationException("Azure credentials not configured for Key Vault access.")

        # Auto-detect Gov Cloud
        is_gov_cloud = ".us" in SCOPE.lower()

        try:
            if is_gov_cloud:
                vault_url = f"https://{KEY_VAULT_NAME}.vault.usgovcloudapi.net"
                credential = ClientSecretCredential(
                    tenant_id=AZURE_TENANT_ID,
                    client_id=AZURE_CLIENT_ID,
                    client_secret=AZURE_CLIENT_SECRET,
                    authority=AzureAuthorityHosts.AZURE_GOVERNMENT,
                )
                applogger.info(
                    f"{self.logs_starts_with}(method={__method_name}) "
                    "Using Azure Government Key Vault endpoint."
                )
            else:
                vault_url = f"https://{KEY_VAULT_NAME}.vault.azure.net"
                credential = ClientSecretCredential(
                    tenant_id=AZURE_TENANT_ID,
                    client_id=AZURE_CLIENT_ID,
                    client_secret=AZURE_CLIENT_SECRET,
                )
                applogger.info(
                    f"{self.logs_starts_with}(method={__method_name}) "
                    "Using Azure Commercial Key Vault endpoint."
                )

            self.client = SecretClient(vault_url=vault_url, credential=credential)
            applogger.info(f"{self.logs_starts_with}(method={__method_name}) KeyVaultManager initialized.")

        except Exception as err:
            applogger.error(f"{self.logs_starts_with}(method={__method_name}) Failed to initialize: {err}")
            raise ConfigurationException(f"Failed to initialize Key Vault client: {err}") from err

    def get_access_token(self) -> Optional[str]:
        """
        Retrieve access token from Key Vault.

        Returns:
            Access token string, or None if not found.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            secret = self.client.get_secret(KV_ACCESS_TOKEN_SECRET)
            applogger.debug(f"{self.logs_starts_with}(method={__method_name}) Retrieved access token.")
            return secret.value
        except ResourceNotFoundError:
            applogger.info(f"{self.logs_starts_with}(method={__method_name}) Access token not found in Key Vault.")
            return None
        except Exception as err:
            applogger.error(f"{self.logs_starts_with}(method={__method_name}) Failed to get access token: {err}")
            return None

    def set_access_token(self, token: str) -> None:
        """
        Store access token in Key Vault.

        Args:
            token: Access token to store.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            self.client.set_secret(KV_ACCESS_TOKEN_SECRET, token)
            applogger.info(f"{self.logs_starts_with}(method={__method_name}) Access token stored in Key Vault.")
        except Exception as err:
            applogger.error(f"{self.logs_starts_with}(method={__method_name}) Failed to set access token: {err}")
            raise ConfigurationException(f"Failed to store access token: {err}") from err

    def get_refresh_token(self) -> Optional[str]:
        """
        Retrieve refresh token from Key Vault.

        Returns:
            Refresh token string, or None if not found.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            secret = self.client.get_secret(KV_REFRESH_TOKEN_SECRET)
            applogger.debug(f"{self.logs_starts_with}(method={__method_name}) Retrieved refresh token.")
            return secret.value
        except ResourceNotFoundError:
            applogger.info(f"{self.logs_starts_with}(method={__method_name}) Refresh token not found in Key Vault.")
            return None
        except Exception as err:
            applogger.error(f"{self.logs_starts_with}(method={__method_name}) Failed to get refresh token: {err}")
            return None

    def set_refresh_token(self, token: str) -> None:
        """
        Store refresh token in Key Vault.

        Args:
            token: Refresh token to store.
        """
        __method_name = inspect.currentframe().f_code.co_name
        try:
            self.client.set_secret(KV_REFRESH_TOKEN_SECRET, token)
            applogger.info(f"{self.logs_starts_with}(method={__method_name}) Refresh token stored in Key Vault.")
        except Exception as err:
            applogger.error(f"{self.logs_starts_with}(method={__method_name}) Failed to set refresh token: {err}")
            raise ConfigurationException(f"Failed to store refresh token: {err}") from err

    def delete_tokens(self) -> None:
        """Delete both access and refresh tokens from Key Vault."""
        __method_name = inspect.currentframe().f_code.co_name
        try:
            self.client.begin_delete_secret(KV_ACCESS_TOKEN_SECRET).wait()
            self.client.begin_delete_secret(KV_REFRESH_TOKEN_SECRET).wait()
            applogger.info(f"{self.logs_starts_with}(method={__method_name}) Tokens deleted from Key Vault.")
        except ResourceNotFoundError:
            applogger.info(f"{self.logs_starts_with}(method={__method_name}) No tokens to delete.")
        except Exception as err:
            applogger.warning(f"{self.logs_starts_with}(method={__method_name}) Failed to delete tokens: {err}")
