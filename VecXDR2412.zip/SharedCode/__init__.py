"""SharedCode package for Vectra XDR Data Connector."""
