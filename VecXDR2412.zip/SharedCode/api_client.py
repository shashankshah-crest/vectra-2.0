"""API client for Vectra XDR with robust retry logic."""

import inspect
import time
import requests
from typing import Dict, Any, Optional

from requests import auth
from SharedCode.logger import applogger
from SharedCode.consts import (
    LOGS_STARTS_WITH,
    VECTRA_API_BASE_URL,
    VECTRA_API_CLIENT_ID,
    VECTRA_API_CLIENT_SECRET,
    STATE_ACCESS_TOKEN_EXPIRY,
    STATE_REFRESH_TOKEN_EXPIRY,
    DETECTIONS_NAME,
)
from SharedCode.exceptions import (
    APIAuthenticationException,
    DataConnectorException,
)
from SharedCode.utils import (
    make_request_with_retry,
    DEFAULT_MAX_RETRIES,
    DEFAULT_BASE_DELAY,
    DEFAULT_MAX_DELAY,
    update_checkpoint_of_disabling_function,
    load_tokens_to_memory,
    store_tokens,
    is_access_token_expired,
    is_refresh_token_expired,
    perform_oauth_request,
    authenticate_with_vectra_api,
)
from SharedCode.keyvault_manager import KeyVaultManager
from SharedCode.state_manager import StateManager


class APIClient:
    """
    API client for Vectra XDR with robust retry logic.

    Features:
    - Automatic token refresh on 401 Unauthorized
    - Exponential backoff for retryable errors (429, 5xx)
    - Network error handling (ConnectionError, Timeout)
    - Immediate failure for non-retryable errors (400, 403, 404, 409)
    """

    def __init__(
        self,
        access_token_secret_name: str,
        refresh_token_secret_name: str,
        access_token_expiry_key: str,
        refresh_token_expiry_key: str,
        state_table_name: str,
        max_retries: int = DEFAULT_MAX_RETRIES,
        base_delay: float = DEFAULT_BASE_DELAY,
        max_delay: float = DEFAULT_MAX_DELAY,
    ):
        """
        Initialize the API client.

        Args:
            access_token_secret_name: Name of access token secret in Key Vault.
            refresh_token_secret_name: Name of refresh token secret in Key Vault.
            access_token_expiry_key: State key for access token expiry timestamp.
            refresh_token_expiry_key: State key for refresh token expiry timestamp.
            state_table_name: Name of the Azure Table Storage table for state.
            max_retries: Maximum number of retry attempts (default: 3).
            base_delay: Base delay for exponential backoff in seconds (default: 5.0).
            max_delay: Maximum delay cap in seconds (default: 60.0).
        """
        self.logs_starts_with = f"{LOGS_STARTS_WITH} APIClient:"
        self.base_url = VECTRA_API_BASE_URL
        self.client_id = VECTRA_API_CLIENT_ID
        self.client_secret = VECTRA_API_CLIENT_SECRET
        self.session = requests.Session()

        # State keys for token expiry
        self.access_token_expiry_key = access_token_expiry_key
        self.refresh_token_expiry_key = refresh_token_expiry_key

        # Initialize Key Vault and State managers with parameterized names
        self.kv_manager = KeyVaultManager(
            access_token_secret_name=access_token_secret_name,
            refresh_token_secret_name=refresh_token_secret_name
        )
        self.state_manager = StateManager(table_name=state_table_name)

        # Retry configuration
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay

        # In-memory token cache (loaded once at initialization using utility function)
        self._token_cache = load_tokens_to_memory(
            self.kv_manager,
            self.state_manager,
            self.access_token_expiry_key,
            self.refresh_token_expiry_key
        )

    def _get_headers(self) -> Dict[str, str]:
        """
        Get request headers with authentication using in-memory cached token.

        Returns:
            Dictionary of headers.
        """
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        access_token = self._token_cache.get("access_token")
        if access_token:
            headers["Authorization"] = f"Bearer {access_token}"
        return headers

    def _refresh_tokens(self) -> bool:
        """
        Re-authenticate to get new tokens (called on 401).

        Returns:
            True if authentication was successful, False otherwise.
        """
        __method_name = inspect.currentframe().f_code.co_name
        applogger.info(
            f"{self.logs_starts_with}(method={__method_name}) Re-authenticating after 401."
        )

        try:
            self.authenticate()
            return True
        except APIAuthenticationException:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) "
                "Re-authentication failed."
            )
            return False
        except Exception as err:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Unexpected error during re-authentication: {err}"
            )
            return False

    def authenticate(self) -> None:
        """
        Authenticate with the Vectra XDR API using utility function.
        
        Logic:
        - If access token is expired or missing:
          - If refresh token is valid: Use refresh token to get new access token
          - If refresh token is expired/missing: Use client credentials

        Raises:
            APIAuthenticationException: If authentication fails.
        """
        authenticate_with_vectra_api(
            base_url=self.base_url,
            client_id=self.client_id,
            client_secret=self.client_secret,
            session=self.session,
            kv_manager=self.kv_manager,
            state_manager=self.state_manager,
            access_token_expiry_key=self.access_token_expiry_key,
            refresh_token_expiry_key=self.refresh_token_expiry_key,
            token_cache=self._token_cache,
            function_name=DETECTIONS_NAME
        )

    def _execute_request(
        self,
        method: str,
        url: str,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        timeout: int = 60,
    ) -> requests.Response:
        """
        Execute a single HTTP request.

        Args:
            method: HTTP method.
            url: Full URL.
            params: Query parameters.
            data: Request body.
            timeout: Request timeout.

        Returns:
            Response object.
        """
        applogger.info(f"DEBUG: URL={url}, Headers={self._get_headers}, Params={params}")
        return self.session.request(
            method=method,
            url=url,
            headers=self._get_headers(),
            params=params,
            json=data,
            timeout=timeout,
        )

    def make_request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        timeout: int = 60,
    ) -> Dict[str, Any]:
        """
        Make an HTTP request to the Vectra API with automatic retry logic.

        Retry behavior:
        - 401: Refresh tokens and retry once
        - 429, 5xx: Retry with exponential backoff
        - ConnectionError, Timeout: Retry with exponential backoff
        - 400, 403, 404, 409: Fail immediately (no retry)

        Args:
            method: HTTP method (GET, POST, etc.).
            endpoint: API endpoint path.
            params: Query parameters.
            data: Request body data.
            timeout: Request timeout in seconds.

        Returns:
            Response data as dictionary.

        Raises:
            APIAuthenticationException: On authentication failures.
            APIRateLimitException: When rate limit retries exhausted.
            InvalidResponseException: On client errors (400, 404, 409).
            DataConnectorException: On other failures.
        """
        __method_name = inspect.currentframe().f_code.co_name
        url = f"{self.base_url}{endpoint}"
        operation_name = f"{method} {endpoint}"

        # Ensure we have a valid token before making request
        if is_access_token_expired(self._token_cache):
            applogger.info(
                f"{self.logs_starts_with}(method={__method_name}) "
                "Token expired or not set. Authenticating."
            )
            self.authenticate()

        # Execute with retry logic
        response = make_request_with_retry(
            session=self.session,
            method=method,
            url=url,
            headers_func=self._get_headers,
            params=params,
            data=data,
            timeout=timeout,
            operation_name=operation_name,
            max_retries=self.max_retries,
            base_delay=self.base_delay,
            max_delay=self.max_delay,
            token_refresher=self._refresh_tokens,
            function_name=DETECTIONS_NAME,
        )

        # Parse and return JSON response
        try:
            return response.json()
        except ValueError as err:
            raise DataConnectorException(f"Invalid JSON response: {err}") from err
