"""API client for Vectra XDR with robust retry logic."""

import inspect
import time
import requests
from typing import Dict, Any, Optional

from requests import auth
from SharedCode.logger import applogger
from SharedCode.consts import (
    LOGS_STARTS_WITH,
    VECTRA_API_BASE_URL,
    VECTRA_API_CLIENT_ID,
    VECTRA_API_CLIENT_SECRET,
    STATE_ACCESS_TOKEN_EXPIRY,
    STATE_REFRESH_TOKEN_EXPIRY,
    DETECTIONS_NAME,
)
from SharedCode.exceptions import (
    APIAuthenticationException,
    DataConnectorException,
)
from SharedCode.utils import (
    make_request_with_retry,
    DEFAULT_MAX_RETRIES,
    DEFAULT_BASE_DELAY,
    DEFAULT_MAX_DELAY,
    update_checkpoint_of_disabling_function,
)
from SharedCode.keyvault_manager import KeyVaultManager
from SharedCode.state_manager import StateManager


class APIClient:
    """
    API client for Vectra XDR with robust retry logic.

    Features:
    - Automatic token refresh on 401 Unauthorized
    - Exponential backoff for retryable errors (429, 5xx)
    - Network error handling (ConnectionError, Timeout)
    - Immediate failure for non-retryable errors (400, 403, 404, 409)
    """

    def __init__(
        self,
        max_retries: int = DEFAULT_MAX_RETRIES,
        base_delay: float = DEFAULT_BASE_DELAY,
        max_delay: float = DEFAULT_MAX_DELAY,
    ):
        """
        Initialize the API client.

        Args:
            max_retries: Maximum number of retry attempts.
            base_delay: Base delay for exponential backoff in seconds.
            max_delay: Maximum delay cap in seconds.
        """
        self.logs_starts_with = f"{LOGS_STARTS_WITH} APIClient:"
        self.base_url = VECTRA_API_BASE_URL
        self.client_id = VECTRA_API_CLIENT_ID
        self.client_secret = VECTRA_API_CLIENT_SECRET
        self.session = requests.Session()

        # Initialize Key Vault and State managers
        self.kv_manager = KeyVaultManager()
        self.state_manager = StateManager(table_name="VectraXDRState")

        # Retry configuration
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay

    def _get_headers(self) -> Dict[str, str]:
        """
        Get request headers with authentication.

        Returns:
            Dictionary of headers.
        """
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        access_token = self.kv_manager.get_access_token()
        if access_token:
            headers["Authorization"] = f"Bearer {access_token}"
        return headers

    def _refresh_tokens(self) -> bool:
        """
        Re-authenticate to get new tokens (called on 401).

        Returns:
            True if authentication was successful, False otherwise.
        """
        __method_name = inspect.currentframe().f_code.co_name
        applogger.info(
            f"{self.logs_starts_with}(method={__method_name}) Re-authenticating after 401."
        )

        try:
            self.authenticate()
            return True
        except APIAuthenticationException:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) "
                "Re-authentication failed."
            )
            return False
        except Exception as err:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Unexpected error during re-authentication: {err}"
            )
            return False

    def _store_tokens(self, data: Dict[str, Any]) -> None:
        """
        Store tokens from authentication response in Key Vault and state table.

        Args:
            data: Response data containing tokens and expiry information.
        """
        __method_name = inspect.currentframe().f_code.co_name

        # Extract tokens
        access_token = data.get("access_token")
        refresh_token = data.get("refresh_token")
        expires_in = data.get("expires_in")
        refresh_expires_in = data.get("refresh_expires_in")

        # Store tokens in Key Vault
        if access_token:
            self.kv_manager.set_access_token(access_token)
        if refresh_token:
            self.kv_manager.set_refresh_token(refresh_token)

        # Calculate and store expiry timestamps in state table
        current_time = time.time()

        if expires_in:
            # Set expiration with 60-second buffer
            access_token_expiry = current_time + expires_in - 60
            self.state_manager.save_state(
                STATE_ACCESS_TOKEN_EXPIRY, access_token_expiry
            )
            applogger.debug(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Access token expiry saved: {access_token_expiry}"
            )

        if refresh_expires_in:
            refresh_token_expiry = current_time + refresh_expires_in - 60
            self.state_manager.save_state(
                STATE_REFRESH_TOKEN_EXPIRY, refresh_token_expiry
            )
            applogger.debug(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Refresh token expiry saved: {refresh_token_expiry}"
            )

    def is_token_expired(self) -> bool:
        """
        Check if the current access token has expired.

        Returns:
            True if token is expired or not set.
        """
        # Check if access token exists in Key Vault
        access_token = self.kv_manager.get_access_token()
        if not access_token:
            return True

        # Check expiry from state table
        access_token_expiry = self.state_manager.get_state(STATE_ACCESS_TOKEN_EXPIRY)
        if access_token_expiry:
            try:
                expiry_time = float(access_token_expiry)
                if time.time() >= expiry_time:
                    return True
            except (ValueError, TypeError):
                # Invalid expiry value, consider expired
                return True

        return False

    def authenticate(self) -> None:
        """
        Authenticate with the Vectra XDR API using client credentials.

        Raises:
            APIAuthenticationException: If authentication fails.
        """
        __method_name = inspect.currentframe().f_code.co_name
        applogger.info(
            f"{self.logs_starts_with}(method={__method_name}) Authenticating with Vectra API."
        )

        auth_url = f"{self.base_url}/oauth2/token"
        payload = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "grant_type": "client_credentials",
        }

        applogger.info(f"DEBUG: {self.logs_starts_with} auth_url={auth_url}, payload= {payload}")

        try:
            response = self.session.post(auth_url, json=payload, timeout=30)
            applogger.info(f"DEBUG: response={response.text}")

            if response.status_code == 200:
                response_data = response.json()
                self._store_tokens(response_data)
                # Added by @Shashank
                update_checkpoint_of_disabling_function(function_name=DETECTIONS_NAME, make_count_zero=True)
                applogger.info(
                    f"{self.logs_starts_with}(method={__method_name}) Authentication successful."
                )
            elif response.status_code == 401:
                # Added by @Shashank
                update_checkpoint_of_disabling_function(function_name=DETECTIONS_NAME)
                raise APIAuthenticationException("Invalid credentials.")
            # need to add more status codes handling
            else:
                raise APIAuthenticationException(
                    f"Authentication failed with status {response.status_code}."
                )

        except requests.exceptions.Timeout as err:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) Request timeout: {err}"
            )
            raise APIAuthenticationException(f"Authentication timeout: {err}") from err
        except requests.exceptions.ConnectionError as err:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) Connection error: {err}"
            )
            raise APIAuthenticationException(
                f"Authentication connection error: {err}"
            ) from err
        except requests.exceptions.RequestException as err:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) Request error: {err}"
            )
            raise APIAuthenticationException(
                f"Authentication request failed: {err}"
            ) from err

    def _make_raw_request(
        self,
        method: str,
        url: str,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        timeout: int = 60,
    ) -> requests.Response:
        """
        Make a raw HTTP request without retry logic.

        Args:
            method: HTTP method.
            url: Full URL.
            params: Query parameters.
            data: Request body.
            timeout: Request timeout.

        Returns:
            Raw Response object.
        """
        return self.session.request(
            method=method,
            url=url,
            headers=self._get_headers(),
            params=params,
            json=data,
            timeout=timeout,
        )

    def make_request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        timeout: int = 60,
    ) -> Dict[str, Any]:
        """
        Make an HTTP request to the Vectra API with automatic retry logic.

        Retry behavior:
        - 401: Refresh tokens and retry once
        - 429, 5xx: Retry with exponential backoff
        - ConnectionError, Timeout: Retry with exponential backoff
        - 400, 403, 404, 409: Fail immediately (no retry)

        Args:
            method: HTTP method (GET, POST, etc.).
            endpoint: API endpoint path.
            params: Query parameters.
            data: Request body data.
            timeout: Request timeout in seconds.

        Returns:
            Response data as dictionary.

        Raises:
            APIAuthenticationException: On authentication failures.
            APIRateLimitException: When rate limit retries exhausted.
            InvalidResponseException: On client errors (400, 404, 409).
            DataConnectorException: On other failures.
        """
        __method_name = inspect.currentframe().f_code.co_name
        url = f"{self.base_url}{endpoint}"

        # Ensure we have a valid token before making request
        if self.is_token_expired():
            applogger.info(
                f"{self.logs_starts_with}(method={__method_name}) "
                "Token expired or not set. Authenticating."
            )
            self.authenticate()

        # Create request function for retry utility
        def request_func() -> requests.Response:
            return self._make_raw_request(method, url, params, data, timeout)

        # Execute with retry logic using utility function
        response = make_request_with_retry(
            request_func=request_func,
            operation_name=f"{method} {endpoint}",
            max_retries=self.max_retries,
            base_delay=self.base_delay,
            max_delay=self.max_delay,
            token_refresher=self._refresh_tokens,
            function_name=DETECTIONS_NAME,  # Added by @Shashank
        )

        # Parse and return JSON response
        try:
            return response.json()
        except ValueError as err:
            raise DataConnectorException(f"Invalid JSON response: {err}") from err
