"""Microsoft Sentinel integration using Log Ingestion API."""
import inspect
from typing import List, Dict, Any
from azure.monitor.ingestion import LogsIngestionClient
from azure.identity import ClientSecretCredential, AzureAuthorityHosts
from azure.core.exceptions import HttpResponseError
from SharedCode.logger import applogger
from SharedCode.consts import (
    LOGS_STARTS_WITH,
    AZURE_CLIENT_ID,
    AZURE_CLIENT_SECRET,
    AZURE_TENANT_ID,
    DCE_ENDPOINT,
    DCR_RULE_ID,
    SCOPE,
)
from SharedCode.exceptions import DataIngestionException, ConfigurationException


class MicrosoftSentinel:
    """Class to handle data ingestion to Microsoft Sentinel using Log Ingestion API."""

    def __init__(self):
        """
        Initialize the MicrosoftSentinel client.

        Automatically detects Azure Government cloud based on DCE endpoint.

        Raises:
            ConfigurationException: If required configuration is missing.
        """
        self.logs_starts_with = f"{LOGS_STARTS_WITH} MicrosoftSentinel:"
        __method_name = inspect.currentframe().f_code.co_name

        if not all([AZURE_CLIENT_ID, AZURE_CLIENT_SECRET, AZURE_TENANT_ID, DCE_ENDPOINT]):
            raise ConfigurationException("Missing required Azure configuration for Sentinel integration.")

        # Auto-detect Gov Cloud based on Scope parameter
        is_gov_cloud = ".us" in SCOPE.lower()

        try:
            if is_gov_cloud:
                applogger.info(
                    f"{self.logs_starts_with}(method={__method_name}) "
                    f"Detected Azure Government cloud from Scope: {SCOPE}"
                )
                credential = ClientSecretCredential(
                    tenant_id=AZURE_TENANT_ID,
                    client_id=AZURE_CLIENT_ID,
                    client_secret=AZURE_CLIENT_SECRET,
                    authority=AzureAuthorityHosts.AZURE_GOVERNMENT,
                )
            else:
                applogger.info(
                    f"{self.logs_starts_with}(method={__method_name}) "
                    f"Using Azure Commercial cloud. Scope: {SCOPE}"
                )
                credential = ClientSecretCredential(
                    tenant_id=AZURE_TENANT_ID,
                    client_id=AZURE_CLIENT_ID,
                    client_secret=AZURE_CLIENT_SECRET,
                )

            self._client = LogsIngestionClient(endpoint=DCE_ENDPOINT, credential=credential)
            applogger.info(f"{self.logs_starts_with}(method={__method_name}) Sentinel client initialized.")

        except Exception as err:
            applogger.error(f"{self.logs_starts_with}(method={__method_name}) Failed to initialize client: {err}")
            raise ConfigurationException(f"Failed to initialize Sentinel client: {err}") from err

    def post_data(
        self,
        events: List[Dict[str, Any]],
        table_name: str,
        dcr_rule_id: str = None,
    ) -> None:
        """
        Post data to Microsoft Sentinel using Log Ingestion API.

        Args:
            events: List of event dictionaries to ingest.
            table_name: Name of the destination table.
            dcr_rule_id: Data Collection Rule ID (optional, uses default from config).

        Raises:
            DataIngestionException: If data ingestion fails.
        """
        __method_name = inspect.currentframe().f_code.co_name

        if not events:
            applogger.info(f"{self.logs_starts_with}(method={__method_name}) No events to ingest.")
            return

        rule_id = dcr_rule_id or DCR_RULE_ID
        stream_name = f"Custom-{table_name}"

        try:
            applogger.info(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Ingesting {len(events)} events to table {table_name}."
            )

            self._client.upload(rule_id=rule_id, stream_name=stream_name, logs=events)

            applogger.info(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Successfully ingested {len(events)} events."
            )

        except HttpResponseError as http_err:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"HTTP error during ingestion: {http_err}"
            )
            raise DataIngestionException(f"HTTP error during data ingestion: {http_err}") from http_err
        except Exception as err:
            applogger.error(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Unexpected error during ingestion: {err}"
            )
            raise DataIngestionException(f"Failed to ingest data: {err}") from err
