"""Business logic for Detections data collection and ingestion."""
import inspect
import time
from typing import List, Dict, Any, Optional, Set
from SharedCode.logger import applogger
from SharedCode.consts import (
    LOGS_STARTS_WITH,
    MAX_EXECUTION_TIME,
    DETECTIONS_EVENTS_ENDPOINT,
    DETECTIONS_DETAILS_ENDPOINT,
    DEFAULT_PAGE_SIZE,
    DETECTIONS_RESPONSE_SIZE,
    DETECTIONS_TABLE_NAME,
    EXCLUDE_GROUPED_DETAILS,
    HOST_MERGE_FIELDS,
    ACCOUNT_MERGE_FIELDS,
    STATE_NEXT_CHECKPOINT,
)
from SharedCode.sentinel import MicrosoftSentinel
from SharedCode.state_manager import StateManager
from SharedCode.api_client import APIClient
from SharedCode.exceptions import (
    DataConnectorException,
    APIAuthenticationException,
    APIRateLimitException,
    DataIngestionException,
    InvalidResponseException,
)


class DetectionsCollector:
    """Collector class for Detections data from Vectra XDR API."""

    def __init__(self):
        """Initialize the DetectionsCollector."""
        self.logs_starts_with = f"{LOGS_STARTS_WITH} DetectionsCollector:"
        self.sentinel = MicrosoftSentinel()
        self.state_manager = StateManager(table_name="VectraXDRState")
        self.api_client = APIClient(
            access_token_secret_name=KV_ACCESS_TOKEN_SECRET,
            refresh_token_secret_name=KV_REFRESH_TOKEN_SECRET,
            access_token_expiry_key=STATE_ACCESS_TOKEN_EXPIRY,
            refresh_token_expiry_key=STATE_REFRESH_TOKEN_EXPIRY,
            state_table_name="VectraXDRState"
        )
        self.start_time = time.time()

    def _is_timeout_approaching(self) -> bool:
        """
        Check if the function execution is approaching timeout.

        Returns:
            bool: True if timeout is approaching, False otherwise.
        """
        return (time.time() - self.start_time) >= MAX_EXECUTION_TIME

    def _fetch_detection_events_page(
        self,
        from_checkpoint: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Fetch a single page of detection events from the API.

        Args:
            from_checkpoint: The 'from' parameter value for pagination.

        Returns:
            API response containing detection events and metadata.

        Raises:
            DataConnectorException: If API request fails.
        """
        __method_name = inspect.currentframe().f_code.co_name

        params = {
            "limit": DEFAULT_PAGE_SIZE,
            "size": DETECTIONS_RESPONSE_SIZE,
        }

        if from_checkpoint:
            params["from"] = from_checkpoint

        applogger.debug(
            f"{self.logs_starts_with}(method={__method_name}) "
            f"Fetching detection events with params: {params}"
        )

        response_data = self.api_client.make_request(
            method="GET",
            endpoint=DETECTIONS_EVENTS_ENDPOINT,
            params=params,
        )

        return response_data

    def _fetch_detection_details(
        self,
        detection_ids: List[int],
    ) -> Dict[int, Dict[str, Any]]:
        """
        Fetch detection details in bulk for given detection IDs.

        Args:
            detection_ids: List of detection IDs to fetch details for.

        Returns:
            Dictionary mapping detection_id to detection details.

        Raises:
            DataConnectorException: If API request fails.
        """
        __method_name = inspect.currentframe().f_code.co_name

        if not detection_ids:
            return {}

        # Build comma-separated list of IDs
        ids_param = ",".join(str(id) for id in detection_ids)

        params = {"id": ids_param}

        # Add exclude_fields if ExcludeGroupedDetails is False
        if not EXCLUDE_GROUPED_DETAILS:
            params["exclude_fields"] = "grouped_details"

        applogger.debug(
            f"{self.logs_starts_with}(method={__method_name}) "
            f"Fetching detection details for {len(detection_ids)} IDs."
        )

        response_data = self.api_client.make_request(
            method="GET",
            endpoint=DETECTIONS_DETAILS_ENDPOINT,
            params=params,
        )

        # Build lookup dictionary by detection ID
        details_lookup: Dict[int, Dict[str, Any]] = {}
        results = response_data.get("results", [])

        for detail in results:
            det_id = detail.get("id")
            if det_id is not None:
                details_lookup[det_id] = detail

        applogger.info(
            f"{self.logs_starts_with}(method={__method_name}) "
            f"Retrieved details for {len(details_lookup)} detections."
        )

        return details_lookup

    def _extract_detection_ids(
        self,
        detection_events: List[Dict[str, Any]],
    ) -> List[int]:
        """
        Extract unique detection IDs from detection events.

        Args:
            detection_events: List of detection event records.

        Returns:
            List of unique detection IDs.
        """
        detection_ids: Set[int] = set()

        for event in detection_events:
            det_id = event.get("detection_id")
            if det_id is not None:
                detection_ids.add(det_id)

        return list(detection_ids)

    def _merge_detection_details(
        self,
        event: Dict[str, Any],
        detail: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Merge detection details into event based on entity type.

        Args:
            event: Original detection event record.
            detail: Detection detail record from /detections endpoint.

        Returns:
            Enriched event with merged detection details.
        """
        # Create a copy to preserve original event
        enriched_event = event.copy()

        # Determine entity type
        entity_type = event.get("type", "")
        enriched_event["entity_type"] = entity_type

        # Add the complete detection details object
        enriched_event["d_detection_details"] = detail

        # Select merge fields based on entity type and merge them at root level
        if entity_type == "host":
            merge_fields = HOST_MERGE_FIELDS
        elif entity_type == "account":
            merge_fields = ACCOUNT_MERGE_FIELDS
        else:
            merge_fields = []

        # Merge selected fields from detail to root level of enriched event
        for field in merge_fields:
            if field in detail:
                enriched_event[field] = detail[field]

        return enriched_event

    def _enrich_detection_events(
        self,
        detection_events: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """
        Enrich detection events with details from /detections endpoint.

        Args:
            detection_events: List of detection event records.

        Returns:
            List of enriched detection events.

        Raises:
            DataConnectorException: If enrichment fails.
        """
        __method_name = inspect.currentframe().f_code.co_name

        if not detection_events:
            return []

        # Step 1: Extract unique detection IDs
        detection_ids = self._extract_detection_ids(detection_events)

        applogger.info(
            f"{self.logs_starts_with}(method={__method_name}) "
            f"Extracted {len(detection_ids)} unique detection IDs from {len(detection_events)} events."
        )

        # Step 2: Fetch detection details in bulk
        details_lookup = self._fetch_detection_details(detection_ids)

        # Step 3: Merge details with events
        enriched_events: List[Dict[str, Any]] = []

        for event in detection_events:
            det_id = event.get("detection_id")
            detail = details_lookup.get(det_id, {})

            if detail:
                enriched_event = self._merge_detection_details(event, detail)
            else:
                # No detail found, add empty d_detection_details
                enriched_event = event.copy()
                enriched_event["entity_type"] = event.get("type", "")
                enriched_event["d_detection_details"] = {}
            
            enriched_event['event_type'] = enriched_event['type']
            enriched_events.append(enriched_event)

        applogger.info(
            f"{self.logs_starts_with}(method={__method_name}) "
            f"Enriched {len(enriched_events)} detection events."
        )

        return enriched_events

    def _collect_and_ingest_page_by_page(
        self,
        initial_checkpoint: Optional[str] = None,
    ) -> tuple[int, Optional[str]]:
        """
        Collect and ingest detections page by page.

        Args:
            initial_checkpoint: Starting checkpoint value.

        Returns:
            Tuple of (total records ingested, final checkpoint value).

        Raises:
            DataConnectorException: If data collection or ingestion fails.
        """
        __method_name = inspect.currentframe().f_code.co_name
        current_checkpoint = initial_checkpoint
        page_count = 0
        total_records = 0

        applogger.info(
            f"{self.logs_starts_with}(method={__method_name}) "
            f"Starting pagination and ingestion from checkpoint: {current_checkpoint}"
        )

        while True:
            # Check for timeout before fetching next page
            if self._is_timeout_approaching():
                applogger.warning(
                    f"{self.logs_starts_with}(method={__method_name}) "
                    f"Timeout approaching. Stopping pagination at page {page_count}. "
                    f"Ingested {total_records} detections so far."
                )
                break

            try:
                # Step 1: Fetch detection events page
                response_data = self._fetch_detection_events_page(from_checkpoint=current_checkpoint)

                # Extract detection events from response
                detection_events = response_data.get("results", [])

                if not detection_events:
                    applogger.info(
                        f"{self.logs_starts_with}(method={__method_name}) "
                        f"Received empty response. Pagination complete."
                    )
                    break

                page_count += 1
                records_in_page = len(detection_events)

                applogger.info(
                    f"{self.logs_starts_with}(method={__method_name}) "
                    f"Page {page_count}: Fetched {records_in_page} detection events."
                )

                # Step 2 & 3: Enrich detection events with details
                enriched_events = self._enrich_detection_events(detection_events)

                applogger.info(
                    f"{self.logs_starts_with}(method={__method_name}) "
                    f"Page {page_count}: Enriched {len(enriched_events)} events. Ingesting to Sentinel."
                )

                # Ingest enriched events to Sentinel
                self.sentinel.post_data(
                    events=enriched_events,
                    table_name=DETECTIONS_TABLE_NAME,
                )

                total_records += records_in_page

                applogger.info(
                    f"{self.logs_starts_with}(method={__method_name}) "
                    f"Page {page_count}: Successfully ingested {records_in_page} detections. "
                    f"Total ingested: {total_records}"
                )

                # Get next checkpoint for pagination
                next_checkpoint = response_data.get("next_checkpoint")

                if not next_checkpoint:
                    applogger.info(
                        f"{self.logs_starts_with}(method={__method_name}) "
                        f"No next_checkpoint in response. Pagination complete."
                    )
                    break

                # Update checkpoint for next iteration
                current_checkpoint = next_checkpoint

                # Save checkpoint after successful ingestion of each page
                self.state_manager.save_state(STATE_NEXT_CHECKPOINT, current_checkpoint)
                applogger.debug(
                    f"{self.logs_starts_with}(method={__method_name}) "
                    f"Checkpoint saved after page {page_count}: {current_checkpoint}"
                )

            except DataIngestionException as ingest_err:
                applogger.error(
                    f"{self.logs_starts_with}(method={__method_name}) "
                    f"Failed to ingest page {page_count}: {ingest_err}. Stopping pagination."
                )
                raise
            except (APIAuthenticationException, APIRateLimitException, InvalidResponseException):
                # Re-raise specific exceptions
                raise
            except Exception as err:
                applogger.error(
                    f"{self.logs_starts_with}(method={__method_name}) "
                    f"Error processing page {page_count + 1}: {err}"
                )
                raise DataConnectorException(f"Failed to process detections page: {err}") from err

        applogger.info(
            f"{self.logs_starts_with}(method={__method_name}) "
            f"Pagination complete. Total pages: {page_count}, Total detections ingested: {total_records}"
        )

        return total_records, current_checkpoint

    def collect_and_ingest(self) -> None:
        """
        Main method to collect detections from API and ingest to Sentinel.

        Raises:
            DataConnectorException: If data collection or ingestion fails.
        """
        __method_name = inspect.currentframe().f_code.co_name
        applogger.info(f"{self.logs_starts_with}(method={__method_name}) Starting data collection.")

        try:
            # Get checkpoint from state table
            initial_checkpoint = self.state_manager.get_state(STATE_NEXT_CHECKPOINT)

            applogger.debug(
                f"{self.logs_starts_with}(method={__method_name}) "
                f"Retrieved checkpoint: {initial_checkpoint}"
            )

            # Collect and ingest data page by page
            total_ingested, final_checkpoint = self._collect_and_ingest_page_by_page(
                initial_checkpoint=initial_checkpoint
            )

            if total_ingested > 0:
                applogger.info(
                    f"{self.logs_starts_with}(method={__method_name}) "
                    f"Successfully ingested {total_ingested} detections across multiple pages."
                )
            else:
                applogger.info(
                    f"{self.logs_starts_with}(method={__method_name}) "
                    "No new detections to ingest."
                )

            # Final checkpoint save (redundant if pages were processed, but ensures state is saved)
            if final_checkpoint:
                self.state_manager.save_state(STATE_NEXT_CHECKPOINT, final_checkpoint)
                applogger.info(
                    f"{self.logs_starts_with}(method={__method_name}) "
                    f"Final checkpoint saved: {final_checkpoint}"
                )

        except APIAuthenticationException as auth_err:
            applogger.error(f"{self.logs_starts_with}(method={__method_name}) Authentication error: {auth_err}")
            raise
        except APIRateLimitException as rate_err:
            applogger.warning(f"{self.logs_starts_with}(method={__method_name}) Rate limit hit: {rate_err}")
            raise
        except DataIngestionException as ingest_err:
            applogger.error(f"{self.logs_starts_with}(method={__method_name}) Ingestion error: {ingest_err}")
            raise
        except InvalidResponseException as resp_err:
            applogger.error(f"{self.logs_starts_with}(method={__method_name}) Invalid response: {resp_err}")
            raise
        except DataConnectorException as dc_err:
            applogger.error(f"{self.logs_starts_with}(method={__method_name}) Data connector error: {dc_err}")
            raise
