"""Azure Function entry point for Detections data connector."""
import azure.functions as func
from .collector import DetectionsCollector
from SharedCode.logger import applogger
from SharedCode.consts import LOGS_STARTS_WITH
import time


def main(mytimer: func.TimerRequest) -> None:
    """
    Azure Function timer trigger entry point for Detections.

    Args:
        mytimer: Timer request object from Azure Functions runtime.
    """
    __method_name = "main"
    logs_starts_with = f"{LOGS_STARTS_WITH} Detections:"
    
    applogger.info(f"{logs_starts_with}(method={__method_name}) Function triggered.")
    
    start_time = time.time()
    
    try:
        collector = DetectionsCollector()
        collector.collect_and_ingest()
        
        end_time = time.time()
        applogger.info(
            f"{logs_starts_with}(method={__method_name}) "
            f"Function completed successfully. Time taken: {end_time - start_time:.2f} seconds."
        )
    except Exception as err:
        applogger.error(f"{logs_starts_with}(method={__method_name}) Error: {err}")
        raise
